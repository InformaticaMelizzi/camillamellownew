package Plugins::MellowDspFIR::Settings;

use strict;
use warnings;

sub new {
    my ($class) = @_;
    return $class;
}

1;
