package Plugins::CamillaMellow::Plugin;

use strict;
use warnings;
use base qw(Slim::Plugin::Base);

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Strings;

my $log = logger('plugin.camillamellow');
my $prefs = preferences('plugin.camillamellow');

# Funzione principale - obbligatoria
sub getDisplayName {
    return 'PLUGIN_CAMILLAMELLOW';
}

# Init plugin - la funzione chiave
sub initPlugin {
    my $class = shift;
    
    $log->info("Initializing CamillaMellow DSP Plugin v0.2.0");
    
    # Inizializza il plugin con menu settings
    $class->SUPER::initPlugin(
        tag    => 'camillamellow',
        menu   => 'settings',
        weight => 80,
    );
    
    # Carica le stringhe di localizzazione
    $class->loadStrings();
    
    $log->info("CamillaMellow DSP Plugin initialized successfully");
    
    return 1;
}

# Shutdown plugin - cleanup
sub shutdownPlugin {
    my $class = shift;
    $log->info("Shutting down CamillaMellow DSP Plugin");
}

# Restituisce il nome del modulo
sub name {
    return 'PLUGIN_CAMILLAMELLOW';
}

# Restituisce la descrizione
sub description {
    return 'PLUGIN_CAMILLAMELLOW_DESC';
}

# Indica che il plugin ha una pagina di settings
sub hasSettings {
    return 1;
}

# Restituisce l'URL della pagina settings
sub settingsPage {
    return 'plugins/CamillaMellow/settings/basic.html';
}

# Tipo di menu - SETTINGS è quello che appare nel player
sub playerMenu {
    return 'SETTINGS';
}

# Peso nel menu (più basso = più alto)
sub weight {
    return 80;
}

# Stato di default
sub defaultState {
    return 'enabled';
}

# Funzione per verificare se il plugin è abilitato per un player
sub enabled {
    my ($class, $client) = @_;
    return $prefs->client($client)->get('enabled', 1);
}

1;
